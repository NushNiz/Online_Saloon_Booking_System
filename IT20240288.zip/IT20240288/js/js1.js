function dofuction(name) {
	
	if(name == "btn1"){
		document.getElementById("bname").innerHTML = ("Beauty");
	    document.getElementById("img1").src = "images/be/be2.WEBP";
        document.getElementById("para1").innerHTML = "Travel Beauty Products That Will Refresh Your Hair, Face, and Body After a Long Flight<br> Price : 23$";
        document.getElementById("img2").src = "images/be/be3.jpg";
		document.getElementById("para2").innerHTML = "Root Science Skincare Review  <br> Price : 22$";
		document.getElementById("img3").src = "images/be/be4.PNG";
        document.getElementById("para3").innerHTML = "Coco Soul Beauty Products  <br> Price : 16$";
        document.getElementById("img4").src = "images/be/be5.WEBP";
		document.getElementById("para4").innerHTML = "Zoe's Beauty <br> Price : 18$";
		document.getElementById("img5").src = "images/be/be6.jpg";
        document.getElementById("para5").innerHTML = "Zero Waste and Plastic-Free Makeup<br> Price : 16$";
        document.getElementById("img6").src = "images/be/be7.jpg";
		document.getElementById("para6").innerHTML = "Ride Or Die Makeup <br> Price : 19$";
		document.getElementById("img7").src = "images/be/be8.jpg";
        document.getElementById("para7").innerHTML = " Fenty Beauty by Rihanna Magnetic Match Stix Trio in colour<br> Price : 25$";
        document.getElementById("img8").src = "images/be/be10.jpg";
		document.getElementById("para8").innerHTML = "Wholesale & OEM Cosmetics Makeup Your Own Brand Brow Powder Name Brand Makeup Concealer Palette<br> Price : 22$";
	}
	else if (name == "btn2"){
		document.getElementById("bname").innerHTML = ("Skin Care ");
		document.getElementById("img1").src = "images/skin/sk1.jpg";
		document.getElementById("para1").innerHTML = "Cream Skin Care Face Flavor <br> Price : 20$";
		document.getElementById("img2").src = "images/skin/sk2.jpg";
		document.getElementById("para2").innerHTML = "Clé de Peau Unveils The Secret To Glowing Skin With Its K<br> Price : 23$";
		document.getElementById("img3").src = "images/skin/sk3.jpg";
		document.getElementById("para3").innerHTML = "Glow Toner <br> Price : 20$";
		document.getElementById("img4").src = "images/skin/sk4.jpg";
		document.getElementById("para4").innerHTML = "Silicone Skin Care<br> Price : 23$";
		document.getElementById("img5").src = "images/skin/sk5.jpg";
		document.getElementById("para5").innerHTML = " Loreal Review <br> Price : 20$";
		document.getElementById("img6").src = "images/skin/sk6.jpg";
        document.getElementById("para6").innerHTML= " Bespoke Beauty<br> Price : 23$";
	}
	else if (name == "btn3"){
		document.getElementById("bname").innerHTML = ("Nail Care");
		document.getElementById("img1").src = "images/nail/n1.jpg";
		document.getElementById("para1").innerHTML = " Red Onyx <br> Price : 20$";
		document.getElementById("img2").src = "images/nail/n2.jpg";
		document.getElementById("para2").innerHTML = "A holographic nail polish featuring a pink shade and a cap<br> Price : 23$";
		document.getElementById("img3").src = "images/nail/n3.jpg";
		document.getElementById("para3").innerHTML = "Holographic nail polishes on my wish list<br> Price : 20$";
		document.getElementById("img4").src = "images/nail/n4.jpg";
		document.getElementById("para4").innerHTML = "ILNP Lulu Swatch & Review <br> Price : 23$";
		document.getElementById("img5").src = "images/nail/n5.jpg";
		document.getElementById("para5").innerHTML = "The Nail Polish Guru <br> Price : 20$";
		document.getElementById("img6").src = "images/nail/n6.jpg";
        document.getElementById("para6").innerHTML = "Essie Nail Care <br> Price : 23$";
	}
	else if (name == "btn4"){
		document.getElementById("bname").innerHTML = ("Hair Care & Styling");
		document.getElementById("img1").src = "images/hair/h1.jpg";
		document.getElementById("para1").innerHTML = " Stylist Silky Hair Color Cream <br> Price : 20$";
		document.getElementById("img2").src = "images/hair/h2.jpg";
		document.getElementById("para2").innerHTML = "STYLE Hair CARE Professional Hair Care Styling Beauty Products<br> Price : 23$";
		document.getElementById("img3").src = "images/hair/h3.jpg";
		document.getElementById("para3").innerHTML = "Rahua Color Full Shampoo <br> Price : 20$";
		document.getElementById("img4").src = "images/hair/h4.jpg";
		document.getElementById("para4").innerHTML = " Herbal Essences | Color Me Happy Shampoo & Body Wash<br> Price : 23$";
		document.getElementById("img5").src = "images/hair/h5.jpg";
		document.getElementById("para5").innerHTML = " Soins du visage<br> Price : 20$";
		document.getElementById("img6").src = "images/hair/h6.jpg";
        document.getElementById("para6").innerHTML = "Magenta Semi Permanent Hair Color<br> Price : 23$";
	}
	else if (name == "btn5"){
		document.getElementById("bname").innerHTML = ("Fragrance");
		document.getElementById("img1").src = "images/fra/f1.jpg";
		document.getElementById("para1").innerHTML = "Notino - Știm cele mai bune parfumuri pentru anul 2019 <br> Price : 20$";
		document.getElementById("img2").src = "images/fra/f2.jpg";
		document.getElementById("para2").innerHTML = "The Best Dior Perfumes for Women<br> Price : 23$";
		document.getElementById("img3").src = "images/fra/f3.jpg";
		document.getElementById("para3").innerHTML = " Poseidon Indómito Instituto Espanol for men<br> Price : 20$";
		document.getElementById("img4").src = "images/fra/f4.jpg";
		document.getElementById("para4").innerHTML = "Embrace the Sunshine With These Summer-Scented Beaut <br> Price : 23$";
		document.getElementById("img5").src = "images/fra/f5.jpg";
		document.getElementById("para5").innerHTML = "Disney Beauty and the Beast Belle Fragrance<br> Price : 20$";
		document.getElementById("img6").src = "images/fra/fr6.jpg";
        document.getElementById("para6").innerHTML ="Princess Belle by Disney for Kids<br> Price : 23$";
	}
	else if (name == "btn6"){
		document.getElementById("bname").innerHTML = ("Men's Grooming");
		document.getElementById("img1").src = "images/men/m1.jpg";
		document.getElementById("para1").innerHTML = "	Norden Men's Grooming: Skincare Inspired by the Sea - World Brand Design <br> Price : 20$";
		document.getElementById("img2").src = "images/men/m2.jpg";
		document.getElementById("para2").innerHTML = "Intense Fragranced Body Spray<br> Price : 23$";
		document.getElementById("img3").src = "images/men/m3.jpg";
		document.getElementById("para3").innerHTML = "Pin on Sothys HOMME <br> Price : 20$";
		document.getElementById("img4").src = "images/men/m4.jpg";
		document.getElementById("para4").innerHTML = " Men's Grooming | Orderchamp<br> Price : 23$";
		document.getElementById("img5").src = "images/men/m5.jpg";
		document.getElementById("para5").innerHTML = "Subzero North For Men da Oriflame - Para o homem atual <br> Price : 20$";
		document.getElementById("img6").src = "images/men/m6.jpg";
        document.getElementById("para6").innerHTML = "Givenchy - Mens grooming - Beauty | Debenhams<br> Price : 23$";
    }
}

function display1(){
	document.getElementById("newad").style.display = "block";
}