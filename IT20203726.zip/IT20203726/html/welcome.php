<!doctype html>
<html>
<head>

		<title>Salon Riverdale</title>
		<link rel="stylesheet" type="text/css" href="../css/header.css">
		
	
		<link rel="stylesheet" href="../css/footercss.css">
		<style>
		.pp{
			
			height:100px;
			weight:100px;
		}
		.button {
  display: inline-block;
  border-radius: 4px;
  background-color:black;
  border: none;
 
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
 
}
.bt{
	
	color:yellow;
}
.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
		
		
		
		
		</style>
	</head>
	<body class="bg">
			<div class="box-area">
				<header><!----------------------------------header------------------------------------------->
					    <div class="wrapper">
						<div class="logo">
							<a href="#"><img class="ima2" src="../images/salon1.jpg"></a>
							<a href="#" >Riverdale</a>
						
						</div>
							<nav>
								<a href="../../IT20207618/html/homepage.html">Home</a>
								<a href="../../IT20207618/html/services.html">Services</a>
								<a href="">Review</a>
								<a href="../../IT20252472/html/Location.html">Location</a>
								<a href="../../IT20240288/contactus.html">Contact Us</a>
								<a href="../../IT20203726/html/about.html">About</a>
                                <a href="../../IT20207618/html/admin-user-login.html">Login</a>
											
							<div class="site-search">
								
							<form action="index.html" method="get">
									
							<input type="search" name="search-box">
							<button type="submit"></button>

							</form>	
					
							</nav>					
						</div>
				</header><!-------------------------------------------end of header--------------------------------------------->
					<div class="uarea"><center><h2>Salon Riverdale</h2></center></div>
					<div class="con">
					<div class="wrapper">
				
                    </div>
					<div class="loginbox">
<!-------------------------------content--------------------------------------------------------->

<div class="header">
<center>
	<h2>welcome to profile</h2>
	<center>
</div>
<center>
<p>	<img  class="pp"   src="../images/pro.png"></p>
<br><br><br><br>

<div class="profile"  >
		
		<center>	 
		     
<button class="button" style="vertical-align:middle"><a   class="bt"  href="update.php"><span>Update account details</span></a></button>
<button class="button" style="vertical-align:middle"><a   class="bt"  href="update.php"><span>Delete account details </span></a></button>

			
</center>		
		
			
	
			
	</div><!--user-details-->
		


 
				
					<br><br>

                <!-------------------------footer----------------------------------------------------------------->
					<fieldset class="ft">
					<table border="0">
					<tr>
					<td class="edit"><img class="image2" src = "../Images/salon.png" style="width:300px; height: 200px; "></td>
					<td class="edit1"><b> HQ </b> 
					<br/>
					NO:12/A,<br/>
					Rockland Place<br/>
					5th Lane,<br/>
					Colombo 6.<br/>
					(+94) 77 2121 889
					</td>
					
					<td class="edit2">
					<b> Branches </b><br/><br/>
					<div class="under">
					<a href = "https://www.google.com/maps/place/Colombo/@6.9218335,79.7861647,12z/data=!4m5!3m4!1s0x3ae253d10f7a7003:0x320b2e4d32d3838d!8m2!3d6.9270786!4d79.861243">Colombo</a><br/><br/>		  
					<a href = "https://www.google.com/maps/place/Malabe/@6.9043203,79.9479226,14z/data=!3m1!4b1!4m5!3m4!1s0x3ae256d59601df81:0x31a1dd96e8d49ba!8m2!3d6.9060787!4d79.9696277">Malabe</a><br/><br/>
					<a href = "https://www.google.com/maps/place/Panadura/@6.729035,79.8944164,13z/data=!3m1!4b1!4m5!3m4!1s0x3ae24616c169e7c3:0xd21e80c970651d56!8m2!3d6.7106361!4d79.9074262">Panadura</a><br/><br/>
					<a href = "https://www.google.com/maps/place/Nugegoda/@6.8656191,79.8881501,14z/data=!3m1!4b1!4m5!3m4!1s0x3ae25a7a9577b535:0x62e4b0a7bd678e33!8m2!3d6.8649081!4d79.8996789">Nugegoda</a><br/><br/>
					<a href = "https://www.google.com/maps/place/Balangoda/@6.6630029,80.6697925,13z/data=!3m1!4b1!4m5!3m4!1s0x3ae3f340fe7adc7b:0x644a4b5a08997d83!8m2!3d6.6668611!4d80.7048084">Balangoda</a><br/><br/>
					<a href = "https://www.google.com/maps/place/Ratnapura/@6.7167744,80.3351204,13z/data=!3m1!4b1!4m5!3m4!1s0x3ae3beb435df712f:0xc14a5df053ff0561!8m2!3d6.7055742!4d80.3847345">Ratnapura</a><br/><br/>
					</div></td>
					
					<td class="edit3">
					<h2><p> Riverdale </p></h2>
					</td>
					
					<td class="edit4">
						<dive class="under1">
					<a href=""> Contact Us</a><br/><br/>
					<a href=""> Terms of use </a><br/><br/>
					<a href=""> Privacy and policy </a><br/><br/>
					<a href=""> Conditions </a><br/><br/>
						</dive>
					</td>
					
					<td class="edit5">
					<h3 class="connect">Connect With Us</h3>
					<hr>
					<table>
						<tr>
					<td class="space"><a href="https://www.facebook.com/"><img id="under3" class="logoo" src="../Images/facebook.png"></a></td>

					<td class="space"><a href="https://twitter.com/" ><img id="under3" class="logoo" src="../Images/twitter.png"></a></td>

					<td class="space"><a href="https://www.instagram.com/" ><img id="under3" class="logoo" src="../Images/instagram.png"></a></td>

					<td class="space1"><a href="https://www.pinterest.com/"><img id="under3" class="logo1" src="../Images/pinterest.png"></a><br/><br/></td><br/>
					
					</tr>
					</table>
					<p>Copyright 2020 Riverdale Salon.<br/><br/>Designated by NN Creations.</p>
					</td>
					
				</tr>
				</table>
			</fieldset>      
		</div>
		</div><br><br>
	
	</body>
	</html>
