function validate()
{
	
var em

em=document.getElementById("email").value;


if(em.length==0){
	alert("fill up the email field!");
}else{
		
		alert("Success");
		
	}

}